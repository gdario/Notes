SUITS = '♠ ♢ ♡ ♣'.split()
